var Express = require('Express');
var bodyParser = require('body-parser');
var Cors = require('cors');
var ItemRoute = require('./FashionShop/itemRoute')
var CategoryRoute = require('./FashionShop/categoryRoute')


var app = Express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(Cors());
app.use('/item', ItemRoute);
app.use('/category', CategoryRoute);

app.listen('8081', '127.0.0.1', function (err) {
    if (err) {
        console.log(err);
        process.exit(-1);
    }

    console.log("Server listen on port 8081")
})