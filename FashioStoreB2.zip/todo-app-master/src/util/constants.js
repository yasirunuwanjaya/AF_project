const COMPLETED = "COMPLETED";
const PENDING = "PENDING";
const INCOMPLETE = "INCOMPLETE";
const API = "http://localhost:8081";

export default {
    COMPLETED,
    INCOMPLETE,
    PENDING,
    API
}