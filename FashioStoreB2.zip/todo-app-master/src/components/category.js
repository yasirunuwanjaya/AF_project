import React, { Component } from 'react'
import axios from 'axios';
import commonConstants from '../util/constants';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import TextField from '@material-ui/core/TextField';

const useStyles = makeStyles => ({
    root: {
        maxWidth: 100,
    },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
    },
    title: {
        fontSize: 24,
    },
    pos: {
        marginBottom: 12,
    },
});

export default class category extends Component {
    constructor(props) {
        super(props)
        this.state = {
            updateCategoryDialogOpen: false,
            categoryName: "",
            categoryDesc: ""
        }
    }

    removeCategory = (id) => {
        axios.delete(commonConstants.API + '/category/' + id).then(results => {
            if (results.status === 200) {
                this.props.getAllCategories();
            }
        })
    }
    handleClickOpen = () => {
        this.setState({
            ...this.state,
            updateCategoryDialogOpen: true,
            categoryName: this.props.category.categoryName,
            categoryDesc: this.props.category.categoryDesc
        })
    };
    handleClose = () => {
        this.setState({
            ...this.state,
            updateCategoryDialogOpen: false
        })
    };
    handleAdd = (id) => {
        // axios.put(commonConstants.API + '/category/' + id, { categoryName: this.state.categoryName, categoryDesc: this.state.categoryDesc }).then(results => {
        //     if (results.status === 200) {
        //         this.props.getAllCategories();
        //     }
        // })
        // this.setState({
        //     ...this.state,
        //     updateCategoryDialogOpen: false
        // })
    }
    onNameChange = (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.setState({
            [event.target.name]: event.target.value
        })

    }
    render() {
        const classes = useStyles();
        return (
            <div>
                <Card className={classes.root} variant="outlined">
                    <CardContent>
                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                            Fashion Shop
                                </Typography>
                        <Typography variant="h5" component="h2">
                            {this.props.category.categoryName}
                        </Typography>
                        <Typography className={classes.pos} color="textSecondary">
                            {this.props.category.categoryDesc}
                        </Typography>
                        <Button variant="outlined" color="primary" onClick={(e) => this.removeCategory(this.props.category._id)}>
                            Remove
                        </Button>
                        <Button variant="outlined" color="primary" onClick={(e) => this.handleClickOpen()}>
                            Edit
                        </Button>
                    </CardContent>
                </Card>
                <Dialog
                    open={this.state.updateCategoryDialogOpen}
                    onClose={this.handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">{"Add New Category"}</DialogTitle>
                    <DialogContent>
                        <div>
                            <TextField id="standard-basic" label="Category Name" name='categoryName' value={this.state.categoryName} onChange={event => this.onNameChange(event)} />
                        </div>
                        <div>
                            <TextField id="standard-basic" label="Category Description" name='categoryDesc' value={this.state.categoryDesc} onChange={event => this.onNameChange(event)} />
                        </div>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.handleAdd(this.props.category._id)} color="primary">
                            Update
                    </Button>
                        <Button onClick={this.handleClose} color="primary" autoFocus>
                            Return
                    </Button>
                    </DialogActions>
                </Dialog>
            </div>
        )
    }
}
